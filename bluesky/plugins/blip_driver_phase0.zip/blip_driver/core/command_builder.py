# -*- coding: utf-8 -*-
"""
Command Builder — سازندهٔ متن فرمان و دستورات backend
======================================================
این ماژول عمداً بدون هیچ وابستگی به Qt نوشته شده تا مستقل قابل تست باشد.

ورودی: یک دیکشنری ساده {category, acid, value, unit}
خروجی: سه چیز جدا (طبق فلسفهٔ FPL_DO_IT در BD_UI_SPEC.md بخش ۲):
  1) fpl_cmd_text   -> متنی که در FPL_CMD نمایش داده می‌شود (خوانا برای اپراتور)
  2) bluesky_cmd    -> رشتهٔ دستور استاندارد BlueSky stack command
  3) fg_props       -> دیکشنری {property_path: value} برای ارسال از طریق Telnet به FG

Phase 0 فقط سه category را پوشش می‌دهد: HDG, ALT, SPD.
هیچ منطق شرطی/ترکیبی (_AT)، واچ‌داگ، یا فاز در این نسخه نیست — طبق تصمیم
"فریز طراحی، شروع کدنویسی" که در گفتگوی پروژه مقرر شد.
"""

from dataclasses import dataclass


@dataclass
class BuiltCommand:
    fpl_cmd_text: str
    bluesky_cmd: str
    fg_props: dict


class UnsupportedCategoryError(Exception):
    """وقتی category خارج از دامنهٔ Phase 0 باشد (فقط HDG/ALT/SPD)."""


def build_command(acid: str, category: str, value: float,
                   vspd_fpm: float | None = None) -> BuiltCommand:
    """
    ساخت هر سه خروجی لازم برای یک دستور سادهٔ HDG/ALT/SPD.

    پارامتر vspd_fpm فقط برای ALT معنا دارد (ROC/D — تصمیم کاربر 2026-08):
    اگر None باشد، BlueSky از نرخ صعود/نزول پیش‌فرض/بیشینهٔ خودِ هواپیما
    استفاده می‌کند (رفتار معادل انتخاب TAB_ALT_FPM_MAX یا ROC/D خاموش).

    ⚠️ نیاز به تأیید: نحو دقیق `ALT acid alt [vspd]` و واحد vspd (فرض شده
    fpm) بر پایهٔ دانش عمومی از BlueSky است، نه BLUESKYCOMMANDTABLE.xlsx
    (که هنوز در پروژه در دسترس من نیست). لطفاً بعد از اولین تست واقعی
    تأیید کنید درست اجرا می‌شود.

    نکتهٔ مهم دربارهٔ FlightGear:
    مسیر property های autopilot زیر یک فرض منطقی و رایج برای اتوپایلوت
    پیش‌فرض FG است (نه یک استاندارد قطعی) — بسته به aircraft/autopilot.xml
    ممکن است فرق کند. این باید توسط کاربر قبل از استفادهٔ واقعی تأیید/تنظیم شود.
    """
    category = category.upper()

    if category == "HDG":
        hdg = int(round(value)) % 360
        fpl_cmd_text = f"{acid} TURN HDG {hdg:03d}"
        bluesky_cmd = f"HDG {acid} {hdg}"
        fg_props = {"/autopilot/settings/heading-bug-deg": hdg}

    elif category == "ALT":
        alt_ft = int(round(value))
        if vspd_fpm:
            fpl_cmd_text = f"{acid} ALT {alt_ft} ROC/D {int(vspd_fpm)}FPM"
            bluesky_cmd = f"ALT {acid} {alt_ft} {int(vspd_fpm)}"
        else:
            fpl_cmd_text = f"{acid} CLIMB/DESCEND ALT {alt_ft}"
            bluesky_cmd = f"ALT {acid} {alt_ft}"
        fg_props = {"/autopilot/settings/target-altitude-ft": alt_ft}
        if vspd_fpm:
            fg_props["/autopilot/settings/vertical-speed-fpm"] = int(vspd_fpm)

    elif category == "SPD":
        spd_kt = int(round(value))
        fpl_cmd_text = f"{acid} SPEED {spd_kt}"
        bluesky_cmd = f"SPD {acid} {spd_kt}"
        fg_props = {"/autopilot/settings/target-speed-kt": spd_kt}

    else:
        raise UnsupportedCategoryError(
            f"دستهٔ '{category}' هنوز در Phase 0 پیاده نشده "
            f"(فقط HDG/ALT/SPD پشتیبانی می‌شوند)."
        )

    return BuiltCommand(fpl_cmd_text=fpl_cmd_text, bluesky_cmd=bluesky_cmd, fg_props=fg_props)
