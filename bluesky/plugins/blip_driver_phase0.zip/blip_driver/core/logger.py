# -*- coding: utf-8 -*-
"""
Command Logger — لاگ append-only JSON-lines برای هر فرمان ارسالی
==================================================================
طبق تصمیم ۴ ARCHITECTURE.md (لایهٔ میانی فرمان) و بخش ۲ BD_UI_SPEC.md
(زنجیرهٔ FPL_DO_IT، مرحلهٔ ۴: "کل فرآیند/دستورات در لاگ ذخیره می‌شود").

فرمت هر خط: یک JSON مستقل با timestamp، acid، category، متن ساخته‌شده،
و نتیجهٔ ارسال به هر backend (موفق/ناموفق/خطا).
"""

import json
import os
from datetime import datetime, timezone


class CommandLogger:
    def __init__(self, log_path: str):
        self.log_path = log_path
        os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)

    def log(self, acid: str, category: str, fpl_cmd_text: str,
             bluesky_result: dict, fg_result: dict):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "acid": acid,
            "category": category,
            "fpl_cmd_text": fpl_cmd_text,
            "bluesky": bluesky_result,
            "flightgear": fg_result,
        }
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return entry
