# -*- coding: utf-8 -*-
"""
StripManager — مدیریت داینامیک strip ها بر اساس ترافیک زنده
================================================================
طبق تصمیم ۳ ARCHITECTURE.md: strip ها داینامیک‌اند — با ورود/خروج هواپیما
در فید WebSocket، خودکار ساخته/حذف می‌شوند.
"""

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QVBoxLayout, QWidget

from core.flight_strip import FlightStrip


class StripManager(QObject):
    # فرمان اپراتور برای dispatch به بیرون (adapters + logger) پاس داده می‌شود
    command_issued = Signal(str, str, float, object)  # (acid, category, value, vspd_fpm)

    def __init__(self, ui_path: str, container_layout: QVBoxLayout, parent=None):
        super().__init__(parent)
        self._ui_path = ui_path
        self._layout = container_layout
        self._strips: dict[str, FlightStrip] = {}

    def on_aircraft_updated(self, aircraft: dict):
        active_ids = set(aircraft.keys())

        # حذف strip هایی که هواپیمایشان دیگر روی رادار نیست
        for acid in list(self._strips.keys()):
            if acid not in active_ids:
                self._remove_strip(acid)

        # ساخت/به‌روزرسانی
        for acid, ac in aircraft.items():
            if acid not in self._strips:
                self._add_strip(acid)
            self._strips[acid].update_from_telemetry(ac)

        self._refresh_order_labels()

    def _refresh_order_labels(self):
        """FPL_ORDER هر strip را با جایگاه واقعی‌اش در layout به‌روز می‌کند.
        ترتیب فعلی = ترتیب چیدمان در scroll area (که FPL_MOVE_UP/DOWN در
        فازهای بعدی همین ترتیب را جابه‌جا خواهند کرد)."""
        total = len(self._strips)
        # ترتیب واقعی روی صفحه را از خودِ layout بخوان، نه از دیکشنری
        # (دیکشنری پایتون ترتیب درج را حفظ می‌کند ولی منبع حقیقت باید UI باشد)
        ordered_acids = [
            acid for acid, strip in self._strips.items()
            if self._layout.indexOf(strip.widget) != -1
        ]
        ordered_acids.sort(key=lambda a: self._layout.indexOf(self._strips[a].widget))
        for position, acid in enumerate(ordered_acids, start=1):
            self._strips[acid].set_order(position, total)

    def _add_strip(self, acid: str):
        strip = FlightStrip(self._ui_path, acid)
        strip.do_it_pressed.connect(self._on_strip_do_it)
        # strip قبل از اسپیسر انتهایی layout اضافه شود
        insert_index = max(self._layout.count() - 1, 0)
        self._layout.insertWidget(insert_index, strip.widget)
        self._strips[acid] = strip

    def _remove_strip(self, acid: str):
        strip = self._strips.pop(acid, None)
        if strip is not None:
            strip.widget.setParent(None)
            strip.widget.deleteLater()

    def _on_strip_do_it(self, acid: str, category: str, value: float, vspd_fpm):
        self.command_issued.emit(acid, category, value, vspd_fpm)

    def strip_count(self) -> int:
        return len(self._strips)
