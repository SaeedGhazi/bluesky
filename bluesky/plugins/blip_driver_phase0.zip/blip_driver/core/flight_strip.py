# -*- coding: utf-8 -*-
"""
FlightStrip — یک نمونهٔ مستقل از strip برای یک هواپیمای واقعی
==================================================================
طبق تصمیم ۵ ARCHITECTURE.md: هر strip یک شیء پایتونی مستقل است، نه ویجت
نام‌گذاری‌شدهٔ دستی در یک .ui بزرگ. این کلاس فایل مستقل `flight_strip.ui`
(استخراج‌شده از FPL1) را با QUiLoader لود می‌کند.

Phase 0 — محدودهٔ عمدی:
  - فقط سه دستور: HDG / ALT / SPD
  - همگام‌سازی زندهٔ TAB_ALT_SPIN/TAB_HDG_SPIN/TAB_SPD_SPIN مگر هنگام ویرایش
    (تصمیم ۱۰ ARCHITECTURE.md) — نسخهٔ ساده، بدون RDL/RTE (که به Core
    ژئودزیک نیاز دارند و در فازهای بعدی اضافه می‌شوند)
  - بدون REPORT، بدون _AT، بدون تشخیص فاز — عمداً حذف شده تا Phase 0 کوچک بماند
"""

from PySide6.QtCore import QFile, Signal, QObject
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QWidget, QRadioButton, QCheckBox, QPushButton, QSpinBox, QTabWidget

from core.command_builder import build_command

# نگاشت مقدار FPM هر رادیوی TAB_ALT_FPM_* — طبق خواستهٔ کاربر (2026-08):
# MAX یعنی «بدون override نرخ» (BlueSky از حداکثر عملکرد خودِ هواپیما
# استفاده می‌کند) -> vspd=None.
# ⚠️ NORMAL هنوز عدد قطعی ندارد — فعلاً مثل MAX رفتار می‌کند (بدون override)
# تا کاربر عدد دقیق را مشخص کند.
FPM_VALUES = {
    "TAB_ALT_FPM_MAX": None,
    "TAB_ALT_FPM_500": 500,
    "TAB_ALT_FPM_1000": 1000,
    "TAB_ALT_FPM_1500": 1500,
    "TAB_ALT_FPM_2000": 2000,
    "TAB_ALT_FPM_NORMAL": None,  # TODO(user): عدد دقیق NORMAL را مشخص کنید
}


class FlightStrip(QObject):
    # (acid, category, value, vspd_fpm) -> برای لاگ/dispatch بیرونی
    # نکته: vspd_fpm از نوع object است چون می‌تواند None باشد (Signal با
    # float نمی‌تواند None منتقل کند)
    do_it_pressed = Signal(str, str, float, object)

    def __init__(self, ui_path: str, acid: str, parent=None):
        super().__init__(parent)
        self.acid = acid
        self.widget: QWidget = self._load_ui(ui_path)

        # ویجت‌های مورد نیاز Phase 0 را یک‌بار پیدا و کش می‌کنیم
        self.w_callsign = self.widget.findChild(QWidget, "FPL_CALLSIGN")
        self.w_type_cat = self.widget.findChild(QWidget, "FPL_TYPE_CAT")
        self.w_cmd_label = self.widget.findChild(QWidget, "FPL_CMD")
        self.w_do_it = self.widget.findChild(QWidget, "FPL_DO_IT")
        self.w_tabs = self.widget.findChild(QWidget, "TABS")
        self.w_order = self.widget.findChild(QWidget, "FPL_ORDER")

        self.w_alt_spin = self.widget.findChild(QWidget, "TAB_ALT_SPIN")
        self.w_hdg_spin = self.widget.findChild(QWidget, "TAB_HDG_SPIN")
        self.w_spd_spin = self.widget.findChild(QWidget, "TAB_SPD_SPIN")

        # ---- ویجت‌های تب ALT (تکمیل 2026-08) ----
        self.w_alt_rocd = self.widget.findChild(QCheckBox, "TAB_ALT_ROCD")
        self.w_alt_fpm_radios: dict[str, QRadioButton] = {
            name: self.widget.findChild(QRadioButton, name) for name in FPM_VALUES
        }
        self.w_alt_inc = {
            100: self.widget.findChild(QPushButton, "TAB_ALT_INC_100"),
            500: self.widget.findChild(QPushButton, "TAB_ALT_INC_500"),
            1000: self.widget.findChild(QPushButton, "TAB_ALT_INC_1000"),
        }
        self.w_alt_dec = {
            100: self.widget.findChild(QPushButton, "TAB_ALT_DEC_100"),
            500: self.widget.findChild(QPushButton, "TAB_ALT_DEC_500"),
            1000: self.widget.findChild(QPushButton, "TAB_ALT_DEC_1000"),
        }

        # نگاشت نام تب -> (اسپین‌باکس، category)
        # نکته: TAB_ALT_SPIN واحدش صد فوت است (maximum=600 در .ui یعنی تا
        # ۶۰۰۰۰ فوت) — طبق مشاهدهٔ ALT_LBL_100 در .ui که کنار آن "00" نشان
        # می‌دهد. برای Phase 0 فرض می‌کنیم مقدار spin مستقیماً بر حسب صد فوت
        # است و در build_command ضرب در ۱۰۰ می‌شود.
        self._tab_map = {
            "TAB_ALT": ("ALT", self.w_alt_spin, 100),   # ضریب تبدیل به فوت
            "TAB_HDG": ("HDG", self.w_hdg_spin, 1),
            "TAB_SPD": ("SPD", self.w_spd_spin, 1),
        }

        if self.w_callsign is not None:
            self.w_callsign.setText(acid)

        if self.w_do_it is not None:
            self.w_do_it.clicked.connect(self._on_do_it_clicked)

        self._wire_alt_tab()
        self._wire_tab_reset()

    # ------------------------------------------------------------------
    # تب ALT — تکمیل 2026-08: INC/DEC، ROC/D، ریست هنگام بازگشت به تب
    # ------------------------------------------------------------------
    def _wire_alt_tab(self):
        # دکمه‌های INC/DEC — فقط مقدار spin را staged می‌کنند (طبق بخش ۳
        # BD_UI_SPEC.md: ارسال واقعی فقط با DO_IT است)
        for delta_ft, btn in self.w_alt_inc.items():
            if btn is not None:
                btn.clicked.connect(lambda _=False, d=delta_ft: self._bump_alt(d))
        for delta_ft, btn in self.w_alt_dec.items():
            if btn is not None:
                btn.clicked.connect(lambda _=False, d=delta_ft: self._bump_alt(-d))

        # ROC/D: رادیوهای FPM فقط وقتی تیک خورده فعال‌اند
        if self.w_alt_rocd is not None:
            self.w_alt_rocd.toggled.connect(self._on_rocd_toggled)
        self._apply_rocd_enable_state()

    def _bump_alt(self, delta_ft: int):
        if self.w_alt_spin is None:
            return
        # spin بر حسب «صد فوت» است (نگاه کامنت بالای _tab_map) — پس دلتای
        # فوت را به واحد صد فوت تبدیل می‌کنیم.
        self.w_alt_spin.setValue(self.w_alt_spin.value() + delta_ft // 100)

    def _on_rocd_toggled(self, checked: bool):
        self._apply_rocd_enable_state()
        if not checked:
            self._uncheck_all_fpm()

    def _apply_rocd_enable_state(self):
        enabled = bool(self.w_alt_rocd is not None and self.w_alt_rocd.isChecked())
        for radio in self.w_alt_fpm_radios.values():
            if radio is not None:
                radio.setEnabled(enabled)

    def _uncheck_all_fpm(self):
        # نکتهٔ Qt: یک QRadioButton با autoExclusive=True (پیش‌فرض) که تنها
        # عضو تیک‌خورده در گروه هم‌محلی‌اش است، با setChecked(False) ساده
        # uncheck نمی‌شود (Qt خودش دوباره checked نگه‌اش می‌دارد). راه‌حل
        # استاندارد: موقتاً autoExclusive را خاموش کن، uncheck کن، برگردان.
        for radio in self.w_alt_fpm_radios.values():
            if radio is not None and radio.isChecked():
                radio.setAutoExclusive(False)
                radio.setChecked(False)
                radio.setAutoExclusive(True)

    def _current_vspd_fpm(self):
        """اگر ROC/D فعال و یک FPM انتخاب شده، مقدارش را برگردان؛ وگرنه None."""
        if self.w_alt_rocd is None or not self.w_alt_rocd.isChecked():
            return None
        for name, radio in self.w_alt_fpm_radios.items():
            if radio is not None and radio.isChecked():
                return FPM_VALUES[name]
        return None

    # ------------------------------------------------------------------
    # ریست تب ALT هنگام خروج/بازگشت (طبق خواستهٔ کاربر 2026-08):
    # هر بار که کاربر از تب دیگری به ALT برمی‌گردد، رادیوهای FPM و ROC/D
    # باید ریست شوند — یعنی حالت آن‌ها «چسبیده» به strip نمی‌ماند.
    # ------------------------------------------------------------------
    def _wire_tab_reset(self):
        if self.w_tabs is None:
            return
        self._prev_tab_index = self.w_tabs.currentIndex()
        self.w_tabs.currentChanged.connect(self._on_tab_changed)

    def _on_tab_changed(self, new_index: int):
        prev_index = getattr(self, "_prev_tab_index", None)
        self._prev_tab_index = new_index

        if prev_index == new_index:
            return
        new_widget = self.w_tabs.widget(new_index)
        if new_widget is not None and new_widget.objectName() == "TAB_ALT":
            self._uncheck_all_fpm()
            if self.w_alt_rocd is not None:
                self.w_alt_rocd.setChecked(False)
            self._apply_rocd_enable_state()

    # ------------------------------------------------------------------
    @staticmethod
    def _load_ui(ui_path: str) -> QWidget:
        loader = QUiLoader()
        f = QFile(ui_path)
        if not f.open(QFile.ReadOnly):
            raise RuntimeError(f"باز کردن {ui_path} ناموفق بود")
        widget = loader.load(f)
        f.close()
        if widget is None:
            raise RuntimeError(f"QUiLoader نتوانست {ui_path} را لود کند: {loader.errorString()}")
        return widget

    # ------------------------------------------------------------------
    def update_from_telemetry(self, ac: dict):
        """
        همگام‌سازی زندهٔ اسپین‌باکس‌ها با دادهٔ واقعی هواپیما — مگر وقتی
        کاربر روی آن ویجت فوکوس دارد (طبق تصمیم ۱۰).
        """
        if self.w_type_cat is not None and ac.get("type"):
            self.w_type_cat.setText(ac["type"])

        live_values = {
            self.w_alt_spin: ac.get("alt"),
            self.w_hdg_spin: ac.get("hdg") if ac.get("hdg") is not None else ac.get("trk"),
            self.w_spd_spin: ac.get("gs"),
        }
        for spin, value in live_values.items():
            if spin is None or value is None:
                continue
            if spin.hasFocus():
                continue  # کاربر در حال ویرایش است — بازنویسی نکن
            scaled = self._scale_for_display(spin, value)
            if scaled is not None:
                spin.blockSignals(True)
                spin.setValue(scaled)
                spin.blockSignals(False)

    def set_order(self, position: int, total: int):
        """طبق درخواست کاربر (2026-08): FPL_ORDER باید عدد زندهٔ "جایگاه/کل"
        نشان دهد، نه متن ثابت. این متد را StripManager بعد از هر تغییر در
        تعداد/ترتیب strip ها روی همهٔ strip های فعال صدا می‌زند."""
        if self.w_order is not None:
            self.w_order.setText(f"{position}/{total}")

    def _scale_for_display(self, spin, raw_value):
        if spin is self.w_alt_spin:
            return int(round(raw_value / 100))  # فوت -> صد فوت (طبق سقف ۶۰۰ در .ui)
        return int(round(raw_value))

    # ------------------------------------------------------------------
    def _on_do_it_clicked(self):
        if self.w_tabs is None:
            return
        current_tab_name = self.w_tabs.currentWidget().objectName() if self.w_tabs.currentWidget() else None
        mapping = self._tab_map.get(current_tab_name)
        if mapping is None:
            self._show_cmd_text(f"تب «{current_tab_name}» هنوز در Phase 0 پشتیبانی نمی‌شود.")
            return

        category, spin, scale = mapping
        if spin is None:
            return
        raw_value = spin.value() * scale

        vspd_fpm = self._current_vspd_fpm() if category == "ALT" else None

        try:
            built = build_command(self.acid, category, raw_value, vspd_fpm=vspd_fpm)
        except Exception as e:  # noqa: BLE001
            self._show_cmd_text(f"خطا در ساخت فرمان: {e}")
            return

        self._show_cmd_text(built.fpl_cmd_text)
        self.do_it_pressed.emit(self.acid, category, raw_value, vspd_fpm)

    def _show_cmd_text(self, text: str):
        if self.w_cmd_label is not None:
            self.w_cmd_label.setText(text)
