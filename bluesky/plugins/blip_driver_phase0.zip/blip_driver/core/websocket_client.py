# -*- coding: utf-8 -*-
"""
WebSocket Telemetry Client
============================
همان فید WebSocket که `flat(BlueSky).html` مصرف می‌کند (از bluesky-bridge.py)،
اینجا با QWebSocket خودِ Qt مصرف می‌شود — بدون نیاز به thread یا کتابخانهٔ
جانبی، چون QWebSocket در همان event loop اصلی Qt کار می‌کند.

فرمت پیام (طبق بررسی flat(BlueSky).html):
{
  "sim_time": "10:23:45",
  "mactid":    ["IRB952", ...],
  "maclat":    [35.37, ...],
  "maclon":    [51.92, ...],
  "macalt":    [21000, ...],
  "machdg":    [230, ...],
  "macgs":     [420, ...],
  ...
}

خروجی این کلاس یک دیکشنری per-callsign ساده‌شده است — فقط فیلدهایی که
Phase 0 لازم دارد (lat, lon, alt, hdg, gs, type). فیلدهای بیشتر بعداً
اضافه می‌شوند (طبق نیاز فازهای بعدی: squawk, situation, ident, ...).
"""

import json

from PySide6.QtCore import QObject, Signal, QTimer, QUrl
from PySide6.QtWebSockets import QWebSocket


class TelemetryClient(QObject):
    # سیگنال‌ها: UI/StripManager فقط باید به این‌ها گوش بدهد، از جزئیات
    # WebSocket بی‌خبر بماند.
    aircraft_updated = Signal(dict)   # {acid: {lat, lon, alt, hdg, gs, type}, ...}
    connection_state_changed = Signal(bool, str)  # (connected, message)

    def __init__(self, url: str, reconnect_delay_sec: int = 3, parent=None):
        super().__init__(parent)
        self._url = QUrl(url)
        self._reconnect_delay_ms = reconnect_delay_sec * 1000

        self._ws = QWebSocket()
        self._ws.connected.connect(self._on_connected)
        self._ws.disconnected.connect(self._on_disconnected)
        self._ws.textMessageReceived.connect(self._on_message)
        self._ws.errorOccurred.connect(self._on_error)

        self._reconnect_timer = QTimer(self)
        self._reconnect_timer.setSingleShot(True)
        self._reconnect_timer.timeout.connect(self._connect)

    def start(self):
        self._connect()

    def stop(self):
        self._reconnect_timer.stop()
        self._ws.close()

    # ------------------------------------------------------------------
    def _connect(self):
        self._ws.open(self._url)

    def _on_connected(self):
        self.connection_state_changed.emit(True, "به فید تلمتری متصل شد.")

    def _on_disconnected(self):
        self.connection_state_changed.emit(False, "اتصال قطع شد — تلاش مجدد...")
        self._reconnect_timer.start(self._reconnect_delay_ms)

    def _on_error(self, _err):
        # errorOccurred قبل از disconnected هم ممکن است بیاید؛ فقط لاگ کن،
        # منطق reconnect در on_disconnected است.
        self.connection_state_changed.emit(False, f"خطای WebSocket: {self._ws.errorString()}")

    def _on_message(self, text: str):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return

        mactid = data.get("mactid")
        if not isinstance(mactid, list) or not mactid:
            return

        aircraft = {}
        for i, acid in enumerate(mactid):
            aircraft[acid] = {
                "acid": acid,
                "lat": _safe_get(data.get("maclat"), i),
                "lon": _safe_get(data.get("maclon"), i),
                "alt": _safe_get(data.get("macalt"), i, 0),
                "hdg": _safe_get(data.get("machdg"), i),
                "trk": _safe_get(data.get("mactrk"), i),
                "gs": _safe_get(data.get("macgs"), i, 0),
                "type": _safe_get(data.get("mactype"), i, "?"),
                "orig": _safe_get(data.get("macorig"), i, ""),
                "dest": _safe_get(data.get("macdest"), i, ""),
            }

        self.aircraft_updated.emit(aircraft)


def _safe_get(arr, idx, default=None):
    if isinstance(arr, list) and idx < len(arr):
        return arr[idx]
    return default
