# -*- coding: utf-8 -*-
"""
BlueSky Adapter — ارسال stack command از طریق ZMQ
====================================================
طبق Adapter Pattern در ARCHITECTURE.md: هستهٔ BD هیچ‌وقت مستقیم با جزئیات
شبکهٔ BlueSky صحبت نمی‌کند؛ فقط از طریق این کلاس.

⚠️ TODO(user) — نیاز به تأیید:
این پیاده‌سازی فرض می‌کند یک سوکت ZMQ REQ ساده روی BLUESKY_ZMQ_CMD_ADDR
یک رشتهٔ متنی stack command (مثل "HDG IRA234 230") را می‌پذیرد و پاسخ کوتاهی
برمی‌گرداند. این فرض بر اساس الگوی معمول BlueSky است، ولی چون کد واقعی
bluesky-bridge.py شما در اختیار من نبود، ممکن است لازم باشد این کلاس با
API واقعی بریج شما (یا اتصال مستقیم به bluesky.network) تطبیق داده شود.
اگر آدرس/روش واقعی متفاوت است، فقط کافیست متد send_command این کلاس را
عوض کنید — بقیهٔ برنامه از این تغییر بی‌اطلاع می‌ماند (این دقیقاً هدف
Adapter Pattern است).
"""

import zmq


class BlueSkyAdapter:
    def __init__(self, zmq_addr: str, timeout_ms: int = 1500):
        self.zmq_addr = zmq_addr
        self.timeout_ms = timeout_ms
        self._ctx = zmq.Context.instance()
        self._socket = None

    def _ensure_socket(self):
        if self._socket is None:
            self._socket = self._ctx.socket(zmq.REQ)
            self._socket.setsockopt(zmq.RCVTIMEO, self.timeout_ms)
            self._socket.setsockopt(zmq.SNDTIMEO, self.timeout_ms)
            self._socket.setsockopt(zmq.LINGER, 0)
            self._socket.connect(self.zmq_addr)

    def send_command(self, stack_cmd: str) -> dict:
        """
        ارسال یک stack command متنی به BlueSky.
        خروجی: {"ok": bool, "detail": str}
        هرگز exception بالا نمی‌دهد — خطاها را در دیکشنری برمی‌گرداند تا
        UI بتواند بدون کرش نتیجه را نمایش دهد.
        """
        try:
            self._ensure_socket()
            self._socket.send_string(stack_cmd)
            reply = self._socket.recv_string()
            return {"ok": True, "detail": reply}
        except zmq.error.Again:
            # timeout — سوکت REQ بعد از خطا باید بازسازی شود
            self._reset_socket()
            return {"ok": False, "detail": "timeout: پاسخی از BlueSky دریافت نشد"}
        except Exception as e:  # noqa: BLE001 — عمداً گسترده، چون این یک لایهٔ مرزی است
            self._reset_socket()
            return {"ok": False, "detail": f"خطا: {e}"}

    def _reset_socket(self):
        if self._socket is not None:
            self._socket.close(0)
            self._socket = None

    def close(self):
        self._reset_socket()
