# -*- coding: utf-8 -*-
"""
FlightGear Adapter — ارسال دستور از طریق Telnet property protocol
====================================================================
طبق ARCHITECTURE.md: شروع با Telnet (ساده‌ترین برای تست)؛ هدف نهایی
مهاجرت به Generic Protocol XML (نگاه بخش "FlightGear Adapter" در سند).

⚠️ TODO(user) — نیاز به تأیید:
مسیرهای property (`/autopilot/settings/...`) در command_builder.py فرض
شده‌اند بر اساس اتوپایلوت پیش‌فرض رایج FG؛ ممکن است aircraft خاص شما
autopilot.xml متفاوتی داشته باشد. لطفاً قبل از استفادهٔ واقعی این مسیرها
را با هواپیمای مورد استفاده تطبیق دهید.
"""

import socket


class FlightGearAdapter:
    def __init__(self, host: str, port: int, timeout_sec: float = 2.0):
        self.host = host
        self.port = port
        self.timeout_sec = timeout_sec

    def send_props(self, props: dict) -> dict:
        """
        ارسال یک یا چند `set /path value` روی یک اتصال Telnet کوتاه‌عمر.
        خروجی: {"ok": bool, "detail": str}
        """
        try:
            with socket.create_connection((self.host, self.port), timeout=self.timeout_sec) as sock:
                sock.settimeout(self.timeout_sec)
                for path, value in props.items():
                    line = f"set {path} {value}\r\n"
                    sock.sendall(line.encode("ascii"))
                    try:
                        sock.recv(1024)  # FG معمولاً یک echo/پاسخ کوتاه برمی‌گرداند
                    except socket.timeout:
                        pass  # نبود پاسخ لزوماً خطا نیست در تلنت FG
            return {"ok": True, "detail": f"{len(props)} property ارسال شد"}
        except (ConnectionRefusedError, socket.timeout, OSError) as e:
            return {"ok": False, "detail": f"اتصال Telnet به FG ناموفق: {e}"}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "detail": f"خطا: {e}"}
