#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BLIP_DRIVER — Phase 0 (نقطهٔ شروع)
=====================================
هدف Phase 0 (طبق تصمیم پروژه در 2026-08-11): یک اپلیکیشن کوچک ولی
end-to-end واقعاً کارکننده، نه مستندسازی بیشتر.

جریان کار:
  ۱) بارگذاری پنجرهٔ اصلی (پوستهٔ ساده — main_window.py)
  ۲) اتصال WebSocket به فید تلمتری زندهٔ bluesky-bridge.py
  ۳) StripManager بر اساس ترافیک واقعی، strip های داینامیک می‌سازد/حذف می‌کند
  ۴) فشردن FPL_DO_IT روی هر strip -> ساخت فرمان -> ارسال هم‌زمان به
     BlueSky (ZMQ) و FlightGear (Telnet) -> لاگ در logs/bd_commands.jsonl

اجرا:
    python3 main.py
"""

import sys

from PySide6.QtWidgets import QApplication

import config
from main_window import MainWindow
from core.websocket_client import TelemetryClient
from core.strip_manager import StripManager
from core.logger import CommandLogger
from adapters.bluesky_adapter import BlueSkyAdapter
from adapters.flightgear_adapter import FlightGearAdapter


class BlipDriverApp:
    def __init__(self):
        self.window = MainWindow()

        self.strip_manager = StripManager(
            ui_path=config.FLIGHT_STRIP_UI_PATH,
            container_layout=self.window.strips_layout,
        )
        self.strip_manager.command_issued.connect(self._dispatch_command)

        self.telemetry = TelemetryClient(
            url=config.WS_TELEMETRY_URL,
            reconnect_delay_sec=config.WS_RECONNECT_DELAY_SEC,
        )
        self.telemetry.aircraft_updated.connect(self.strip_manager.on_aircraft_updated)
        self.telemetry.connection_state_changed.connect(self.window.set_connection_status)

        self.bluesky = BlueSkyAdapter(config.BLUESKY_ZMQ_CMD_ADDR)
        self.flightgear = FlightGearAdapter(config.FG_TELNET_HOST, config.FG_TELNET_PORT,
                                              config.FG_TELNET_TIMEOUT_SEC)
        self.logger = CommandLogger(config.COMMAND_LOG_PATH)

    def start(self):
        self.window.show()
        self.telemetry.start()

    # ----------------------------------------------------------------
    def _dispatch_command(self, acid: str, category: str, value: float, vspd_fpm):
        """
        طبق زنجیرهٔ FPL_DO_IT در BD_UI_SPEC.md بخش ۲:
        ساخت متن -> ارسال BlueSky -> ارسال FG -> لاگ.
        (متن FPL_CMD قبلاً خودِ FlightStrip روی UI نشان داده — اینجا فقط
        dispatch واقعی به بک‌اندها انجام می‌شود. vspd_fpm از خودِ strip
        می‌آید تا اینجا دوباره حدس زده نشود.)
        """
        from core.command_builder import build_command
        built = build_command(acid, category, value, vspd_fpm=vspd_fpm)

        bluesky_result = self.bluesky.send_command(built.bluesky_cmd)
        fg_result = self.flightgear.send_props(built.fg_props)

        self.logger.log(
            acid=acid, category=category, fpl_cmd_text=built.fpl_cmd_text,
            bluesky_result=bluesky_result, fg_result=fg_result,
        )

        if not bluesky_result["ok"]:
            print(f"[BlueSky] هشدار: {bluesky_result['detail']}")
        if not fg_result["ok"]:
            print(f"[FlightGear] هشدار: {fg_result['detail']}")


def main():
    app = QApplication(sys.argv)
    bd = BlipDriverApp()
    bd.start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
