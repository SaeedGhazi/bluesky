# -*- coding: utf-8 -*-
"""
MainWindow — پوستهٔ حداقلی Phase 0
=====================================
⚠️ این یک پنجرهٔ ساده و موقت است — جایگزین BLIP_DRIVER.ui نیست.
BLIP_DRIVER.ui همچنان بوم طراحی/پروتوتایپ اصلی شماست و در Phase 0
دست‌نخورده می‌ماند. وقتی UI اصلی به مرحلهٔ پایدار رسید، این پنجرهٔ ساده با
لود مستقیم BLIP_DRIVER.ui (شامل RADAR_MAP) جایگزین می‌شود.

هدف این فایل فقط این است: یک محفظهٔ قابل‌اسکرول برای strip های داینامیک +
یک نوار وضعیت اتصال، تا Phase 0 قابل اجرا و تست باشد.
"""

from PySide6.QtWidgets import (
    QMainWindow, QScrollArea, QWidget, QVBoxLayout, QLabel, QSpacerItem, QSizePolicy
)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BLIP_DRIVER — Phase 0")
        self.resize(760, 700)

        central = QWidget()
        self.setCentralWidget(central)
        outer_layout = QVBoxLayout(central)

        self.status_label = QLabel("در حال اتصال به فید تلمتری...")
        outer_layout.addWidget(self.status_label)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer_layout.addWidget(scroll)

        strips_container = QWidget()
        self.strips_layout = QVBoxLayout(strips_container)
        self.strips_layout.addSpacerItem(
            QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        )
        scroll.setWidget(strips_container)

    def set_connection_status(self, connected: bool, message: str):
        prefix = "🟢" if connected else "🔴"
        self.status_label.setText(f"{prefix} {message}")
