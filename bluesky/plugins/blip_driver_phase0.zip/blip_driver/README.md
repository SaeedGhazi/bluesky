# BLIP_DRIVER — Phase 0

اپلیکیشن حداقلی ولی end-to-end. هدف: یک بار کل مسیر داده رو کار بندازیم
(UI → تلمتری زنده → strip داینامیک → دستور ساده → BlueSky/FG → لاگ) قبل از
اضافه‌کردن هر قابلیت دیگری.

## نصب

```bash
pip install -r requirements.txt
```

## اجرا

```bash
python3 main.py
```

پیش‌نیاز اجرای واقعی (نه تست ساختاری): `bluesky-bridge.py` باید روی
`ws://localhost:8080` در حال پخش تلمتری باشد (همان فیدی که
`flat(BlueSky).html` استفاده می‌کند).

## چه چیزی کار می‌کند (تست‌شده، بدون کرش)

- بارگذاری `ui/flight_strip.ui` (استخراج‌شده از `FPL1` در `BLIP_DRIVER.ui`)
- اتصال WebSocket با reconnect خودکار
- ساخت/حذف داینامیک strip بر اساس `mactid` ورودی از فید
- همگام‌سازی زندهٔ `TAB_ALT_SPIN` / `TAB_HDG_SPIN` / `TAB_SPD_SPIN` با
  تلمتری واقعی — **مگر وقتی کاربر روی آن ویجت فوکوس دارد** (تصمیم ۱۰)
- فشردن `FPL_DO_IT` روی تب‌های `ALT`/`HDG`/`SPD`:
  - متن `FPL_CMD` ساخته و نمایش داده می‌شود
  - فرمان به BlueSky (ZMQ) و FlightGear (Telnet) ارسال می‌شود
  - هر دو نتیجه (موفق/ناموفق) در `logs/bd_commands.jsonl` ثبت می‌شود
- روی هر تب دیگر (غیر از ALT/HDG/SPD)، `DO_IT` پیام «هنوز پشتیبانی
  نمی‌شود» نشان می‌دهد و کرش نمی‌کند

## ⚠️ نکاتی که قبل از تست با BlueSky/FG واقعی نیاز به تأیید/تنظیم شما دارند

این‌ها را در `config.py` و کامنت بالای `adapters/*.py` علامت زده‌ام:

1. **`BLUESKY_ZMQ_CMD_ADDR`** (`config.py`) — فرض شده یک سوکت ZMQ REQ ساده
   روی `tcp://localhost:9000` یک رشتهٔ متنی مثل `"HDG IRA234 230"` می‌پذیرد.
   چون کد `bluesky-bridge.py` شما در اختیارم نبود، این فرض ممکن است با
   کانال واقعی ارسال فرمان شما فرق کند — لطفاً `adapters/bluesky_adapter.py`
   را بر همین اساس تطبیق دهید (فقط همین یک فایل، بقیهٔ برنامه بی‌اطلاع
   می‌ماند).
2. **مسیرهای property در `core/command_builder.py`** برای FG
   (`/autopilot/settings/heading-bug-deg` و مشابه) — فرضی رایج‌اند، نه
   تضمینی؛ به `autopilot.xml` هواپیمای مورد استفاده‌تان در FG بستگی دارد.
3. **ضریب تبدیل `TAB_ALT_SPIN`** — چون سقف spin در `.ui` عدد ۶۰۰ است (نه
   ۶۰۰۰۰)، فرض شده واحدش «صد فوت» است (`FL` بدون `FL`، شبیه `ALT_LBL_100`
   کنارش که "00" نشان می‌دهد). این فرض در `flight_strip.py` کامنت‌گذاری
   شده — لطفاً تأیید کنید درست است یا نه.

## چه چیزی عمداً در Phase 0 نیست

طبق تصمیم «فریز طراحی، شروع کدنویسی»: بدون RDL/RTE (نیاز به Core
ژئودزیک)، بدون `FPL_REPORT`، بدون چک‌باکس‌های `_AT`، بدون تشخیص فاز، بدون
`AirportDataStore`/خواندن واقعی `SETTINGS.cfg`، بدون embed کردن
`RADAR_MAP` (`QWebEngineView`) در پنجرهٔ اصلی. این‌ها فازهای بعدی‌اند
(نگاه `PROJECT_STATUS.md`).

## ساختار فایل‌ها

```
main.py                        نقطهٔ ورود
main_window.py                 پوستهٔ ساده و موقت پنجره (نه جایگزین BLIP_DRIVER.ui)
config.py                      تنظیمات هاردکد Phase 0
ui/flight_strip.ui             استخراج‌شده از FPL1 — یک strip مستقل
core/
  websocket_client.py          مصرف‌کنندهٔ فید تلمتری (QWebSocket)
  strip_manager.py             ساخت/حذف داینامیک strip
  flight_strip.py              کلاس یک strip (بار‌گذاری .ui + منطق DO_IT)
  command_builder.py           ساخت متن فرمان + دستورات هر بک‌اند (بدون Qt، مستقل تست‌شدنی)
  logger.py                    لاگ JSON-lines
adapters/
  bluesky_adapter.py           ارسال به BlueSky از طریق ZMQ
  flightgear_adapter.py        ارسال به FG از طریق Telnet
```
