# -*- coding: utf-8 -*-
"""
تنظیمات پایه‌ی Phase 0
======================
مقادیر این فایل موقتی/هاردکد هستند (طبق تصمیم Phase 0: سادگی در اولویت است).
در فازهای بعدی این مقادیر باید از SETTINGS.cfg خوانده شوند (تصمیم ۸ ARCHITECTURE.md).

⚠️ نکات نیازمند تأیید کاربر (TODO های صریح):
  - آدرس/پورت دقیق کانال ارسال فرمان به BlueSky (فعلاً فرض: ZMQ REQ روی همان
    ماشین، پورت پیش‌فرض BlueSky برای stack command). اگر bluesky-bridge.py
    شما کانال دیگری برای ارسال دارد (مثلاً از طریق خود بریج)، این مقدار را
    عوض کنید.
  - آدرس/پورت Telnet برای FlightGear (فرض: localhost:5501 طبق ARCHITECTURE.md).
"""

# فید تلمتری زنده (همان چیزی که flat(BlueSky).html استفاده می‌کند)
# نکته: عمداً 127.0.0.1 به‌جای localhost — چون WS_HOST بریج (0.0.0.0) فقط
# IPv4 است، و روی برخی سیستم‌ها "localhost" اول به ::1 (IPv6) resolve
# می‌شود که هیچ‌کس رویش گوش نمی‌دهد و "Connection refused" کاذب می‌دهد.
WS_TELEMETRY_URL = "ws://127.0.0.1:8080"

# --- BlueSky ---
# ✅ حل شد (2026-08): این پورت متعلق به گیرندهٔ فرمان جدیدی است که به
# atc_extras.py اضافه شد (ZMQ REP روی 11010، داخل خودِ فرآیند BlueSky).
# اگر atc_extras.py را آپدیت نکرده‌اید، این آدرس به هیچ‌جا وصل نمی‌شود —
# نگاه atc_extras_updated.py برای نسخهٔ به‌روزشده.
BLUESKY_ZMQ_CMD_ADDR = "tcp://127.0.0.1:11010"

# --- FlightGear ---
FG_TELNET_HOST = "localhost"
FG_TELNET_PORT = 5501
FG_TELNET_TIMEOUT_SEC = 2.0

# مسیر فایل .ui یک strip مستقل (استخراج‌شده از FPL1 در BLIP_DRIVER.ui)
FLIGHT_STRIP_UI_PATH = "ui/flight_strip.ui"

# مسیر فایل لاگ (JSON-lines) — طبق تصمیم ۴ ARCHITECTURE.md، هر فرمان DO_IT
# باید لاگ شود.
COMMAND_LOG_PATH = "logs/bd_commands.jsonl"

# فاصله‌ی تلاش مجدد اتصال WebSocket (ثانیه)
WS_RECONNECT_DELAY_SEC = 3
